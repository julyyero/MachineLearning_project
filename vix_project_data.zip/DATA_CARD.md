# Data card — "Will the volatility seller lose this month?" (S&P 500 / VIX)

## Task
For each trading day t (decision at the close of t):

    y_t = 1  if  RV(t+1 .. t+21) > VIX_t / 100,   else 0
    RV(t+1 .. t+21) = sqrt(252/21 * sum_{k=1..21} r_{t+k}^2),   r_t = ln(S_t / S_{t-1})

y_t = 1 means a seller of 1-month S&P 500 variance (strike ~ VIX^2) loses money.

## Files
| File | Content |
|---|---|
| `data/processed/vix_dataset.csv` | 9,175 rows, 1990-03-05 → 2026-08-26, 14 features. Features known at close t + label + `split`. **Model input.** |
| `data/processed/vix_eval_only.csv` | Same dates: forward realised volatility and the short-variance P&L proxy. **Future information: evaluation / threshold choice only, never features.** |
| `data/raw/sp500_gspc_yahoo.csv` | S&P 500 (^GSPC) daily OHLCV 1980-01-02 → 2026-09-25, unmodified source file. |
| `data/raw/vix_daily_cboe.csv` | VIX daily OHLC 1990-01-02 → 2026-09-22, unmodified source file. |
| `data/raw/fx_daily_fed_h10.csv` | Federal Reserve H.10 daily exchange rates (units per USD), 1971 → 2026-11-20; rows for the euro, Danish krone, yen, pound, Canadian dollar, Swedish krona and Swiss franc extracted from the source file, values unmodified. |
| `data/raw/brent_daily_eia.csv` | Brent crude spot price (EIA), daily 1987-05-20 → 2026-11-17, unmodified source file. |
| `data/raw/BAA10Y.csv` | FRED `BAA10Y` (Moody's Baa yield minus 10-year Treasury), daily 1990-01-31 → 2026-08-26, downloaded from FRED by the team, unmodified. |
| `src/build_dataset.py` | Rebuilds both processed files from the raw files (deterministic). |

## Columns of `vix_dataset.csv` (volatilities and returns in %, same unit as the VIX)
| Column | Definition (all use data up to the close of t only) |
|---|---|
| `vix` | VIX_t: implied volatility of the S&P 500 for the next 30 days, % |
| `vix_log` | ln(VIX_t) |
| `vix_change_5d` | 100 · ln(VIX_t / VIX_{t−5}) |
| `realized_vol_past_5d`, `_21d`, `_63d` | 100 · sqrt(252/n · Σ_{k=0..n−1} r²_{t−k}), annualised, % |
| `sp500_return_5d`, `sp500_return_21d` | 100 · ln(S_t/S_{t−5}), 100 · ln(S_t/S_{t−21}) |
| `dollar_index_change_21d` | 100 · ln(USDX_t / USDX_{t−21}); USDX = ICE DXY formula (EUR 57.6 %, JPY 13.6 %, GBP 11.9 %, CAD 9.1 %, SEK 4.2 %, CHF 3.6 %) applied to Fed H.10 rates; before 1999-01-04 the Danish krone (pegged to the Deutsche mark) stands for the euro block. > 0 = dollar strengthening |
| `brent_oil_return_21d` | 100 · ln(Brent_t / Brent_{t−21}) |
| `sp500_volume_5d_vs_3m` | 100 · ln(median volume of the last 5 days / median volume of the last 63 days); > 0 = more trading than usual |
| `credit_spread_baa10y`, `credit_spread_change_21d` | Moody's Baa yield minus 10-year Treasury (pp) and its 21-day change (bp). FRED publishes the value of day t on t+1, so the value used at t is the one dated t−1. |
| `seller_lost_last_month` | label of t−21: its window ends at t, so it is known at the close of t (`y.shift(1)` would leak 20 future days) |
| `target_seller_loses_next_month` | **label** y_t (see above) |
| `split` | `train` (1990-03-05 → 2022-11-30, 8,239 rows, prevalence 14.7 %), `purge` (2022-12-01 → 2022-12-30, 21 rows whose label window reaches into 2023 — exclude), `test` (2023-01-03 → 2026-08-26, 915 rows, prevalence 10.3 %) |

Columns of `vix_eval_only.csv` (FUTURE information): `vix`, `realized_vol_next_21d` (%), `seller_pnl_variance` = (vix/100)² − (realized_vol_next_21d/100)², `target_seller_loses_next_month`, `split`.

## Sources (retrieved 2026-11-24)
- S&P 500: Yahoo Finance ^GSPC export, file `data/raw/sp500_yfinance_original.csv` of the GitHub repository Muhammad-Ibrahim324/S-P-500-Historical-Prices-Analysis. That repository did not reconcile the data with another provider, so we did (below).
- VIX: Cboe daily closes via the datahub "core" dataset `finance-vix` (GitHub repository datasets/finance-vix, `data/vix-daily.csv`).
- Credit spread: FRED series `BAA10Y` (https://fred.stlouisfed.org/series/BAA10Y), downloaded by the team.
- Brent: EIA daily spot price via the datahub "core" dataset `oil-prices` (`data/brent-daily.csv`).
- Exchange rates for the dollar index: Federal Reserve H.10 (https://www.federalreserve.gov/releases/h10/) via the datahub "core" dataset `exchange-rates` (`data/daily.csv`).

## Cross-validation performed
- S&P 500 closes vs an independent Yahoo history (vijinho/sp500, 1990-2018): 7,302 common days, max relative difference 5.7e-8, same calendar.
- S&P 500 closes vs a separate yfinance export (2021-2024): 1,005 days, identical.
- S&P 500 vs 35 FRED `SP500` closes (2020-2026): identical. VIX vs 66 FRED `VIXCLS` closes (2014-2026): identical.
- VIX maximum close 82.69 on 2020-03-16; 80.86 on 2008-11-20 (known values).
- BAA10Y vs 20 values read on FRED pages (2015-2026): identical. Maximum 6.16 on 2008-12-04.
- Brent vs 20 FRED `DCOILBRENTEU` values (2025-2026): identical.
- Rebuilt dollar index vs published DXY closes: 108.51 vs 108.49 on 2024-12-31, 113.96 vs 114.11 on 2022-09-27 (Fed rates are noon fixings, the DXY a close). Daily changes of the Danish krone and of the euro are correlated at 0.98 over 1999-2026, which supports the pre-1999 proxy.
- Rejected source: SteelCerberus/us-market-data "Close" — daily returns differ from ^GSPC by up to 3 % (series approximates SPY with dividends / expense ratio).

## Data-quality findings and treatment
- 34 VIX rows fall on days the S&P 500 did not trade (2004-06-11 and U.S. holidays since 2022; Cboe publishes VIX on some holidays, FRED too). Dropped by aligning on the S&P 500 calendar.
- 4 S&P 500 trading days have no VIX value (1991-03-01, 1997-01-31, 1997-11-26, 1999-12-31). Rows dropped; their returns still count inside the RV windows.
- 5 S&P 500 days with an exactly zero return since 1990 (e.g. 2008-01-03): kept (plausible unchanged closes, not independently verified).
- Extreme values are real events and are kept (e.g. S&P 500 −12.0 % on 2020-03-16, VIX ×2.16 on 2018-02-05).
- VIX before September 2003 is back-calculated by Cboe with the current methodology.
- Brent, the dollar index and the credit spread are aligned on the S&P 500 calendar with the last value observed on or before t (at most 10 days old): the EIA Brent series has gaps of 6-9 days in the 1990s-2000s, and BAA10Y is blank on bond-market holidays (398 rows).
- The BAA10Y file starts on 1990-01-31, so its 21-day change exists from 1990-03-05: the dataset starts there (22 rows lost, none positive).
- Brent rather than WTI: WTI settled at −36.98 USD on 2020-04-20, a negative price for which a log-return is undefined.
- S&P 500 volume: 3 errors in the Yahoo series set to missing — 1996-11-29 (3 % of normal volume), 2011-02-16 → 2011-03-02 (≈ 30 % of normal on regular sessions), 2023-05-24 (zero). Low volume on half-days (day after Thanksgiving, Christmas Eve, July 3) is real and kept; the medians make the feature robust to it. Raw volume grows ×100 between 1980 and 2026, hence a relative measure.
- Gold and Treasury yields were considered, but no daily open source was reachable at build time (only monthly series).

## Leakage safeguards (verified by `build_dataset.py`)
- Label is NaN (rows dropped) when the 21 future returns are not observed: `(a > NaN)` would silently give 0.
- Look-ahead test: features recomputed with data truncated at t are identical on 40 random dates.
- Label recomputed by an explicit loop on 40 random dates: identical.
- Univariate ROC-AUC of every feature on train lies between 0.52 and 0.58 (highest: `credit_spread_change_21d`): no feature leaks the label, and the signal is weak.
- The credit spread is lagged by one business day (publication lag), and the look-ahead test covers it.
- Brent and the dollar index are weakly correlated with the other features (|ρ| ≤ 0.33 and ≤ 0.20); the credit spread level is correlated with past realised volatility (up to 0.70), its 21-day change less so (≤ 0.46); the volatility features are correlated with each other up to 0.88.
- Rebuilding twice gives identical SHA-256 hashes (see `SHA256SUMS.txt`).

## Limitations
- Close-to-close RV from 21 daily returns is a noisy estimate of realised volatility; VIX covers 30 calendar days, the label 21 trading days.
- Overlapping labels: consecutive rows share 20 of 21 return days → use `TimeSeriesSplit(gap=21)`, never shuffled K-fold; ≈ 430 independent months.
- `seller_pnl_variance` ignores transaction costs, the convexity of the real variance-swap strike and vega notional scaling.
- Licensing: Yahoo data are subject to Yahoo's terms (personal / educational use); the source repository states no redistribution rights. Use for coursework, cite the sources, do not republish the raw files.

## Reproduce
    python src/build_dataset.py      # pandas 3.0.5, numpy 2.5.3 used here
