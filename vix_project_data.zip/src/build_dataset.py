"""Build the VIX / realized-volatility classification dataset.

Question for each trading day t (decided at the close of t):
    will the S&P 500 realized volatility over the next 21 trading days
    exceed the implied volatility quoted today (VIX_t)?
    y_t = 1  if  RV(t+1 .. t+21) > VIX_t / 100,  else 0

Inputs  (data/raw/):   sp500_gspc_yahoo.csv, vix_daily_cboe.csv,
                       brent_daily_eia.csv (oil), fx_daily_fed_h10.csv (exchange rates for the dollar index),
                       optional BAA10Y.csv (credit spread, FRED download: used only if the file is present)
Outputs (data/processed/):
    vix_dataset.csv    features known at close t + label y + split column
    vix_eval_only.csv  FUTURE information (forward RV, short-variance P&L proxy).
                       Use only to evaluate / choose the decision threshold, never as features.

Run from the repository root:  python src/build_dataset.py
"""
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW, OUT = ROOT / "data" / "raw", ROOT / "data" / "processed"
H = 21                      # label horizon in trading days (VIX ~ 30 calendar days)
ANN = 252                   # annualisation factor
TEST_START = pd.Timestamp("2023-01-01")
# Yahoo volume errors found in the audit (normal sessions with near-zero volume): set to missing
# ICE U.S. Dollar Index (DXY) weights; rates are expressed in units of currency per USD
DXY_WEIGHTS = {"Euro": 0.576, "Japan": 0.136, "United Kingdom": 0.119, "Canada": 0.091,
               "Sweden": 0.042, "Switzerland": 0.036}
EURO_START = pd.Timestamp("1999-01-04")
BAD_VOLUME = [("1996-11-29", "1996-11-29"), ("2011-02-16", "2011-03-02"), ("2023-05-24", "2023-05-24")]


def load_raw():
    # yfinance export: 3 header rows (Price / Ticker / Date) before the data
    yahoo = pd.read_csv(RAW / "sp500_gspc_yahoo.csv", skiprows=3, header=None,
                        names=["date", "close", "high", "low", "open", "volume"],
                        parse_dates=["date"]).set_index("date")
    spx = yahoo["close"].astype(float)
    volume = yahoo["volume"].astype(float).replace(0, np.nan)
    for a, b in BAD_VOLUME:
        volume.loc[a:b] = np.nan
    vix = pd.read_csv(RAW / "vix_daily_cboe.csv", parse_dates=["DATE"]
                      ).set_index("DATE")["CLOSE"].astype(float)
    vix.index.name = "date"
    fx = pd.read_csv(RAW / "fx_daily_fed_h10.csv", parse_dates=["Date"]).dropna()
    other = {
        "usd_index": dollar_index(fx),
        "brent": pd.read_csv(RAW / "brent_daily_eia.csv", parse_dates=["Date"]
                             ).set_index("Date")["Price"].astype(float),                               # USD per barrel
    }
    aux = {"volume": volume, "credit": None}
    credit_file = RAW / "BAA10Y.csv"                       # FRED: observation_date (or DATE), BAA10Y
    if credit_file.exists():
        c = pd.read_csv(credit_file)
        c = pd.Series(pd.to_numeric(c.iloc[:, 1], errors="coerce").values,
                      index=pd.to_datetime(c.iloc[:, 0])).dropna()
        # FRED publishes the value of day t on t+1: it is only known at the close of the next business day
        c.index = c.index + pd.offsets.BDay(1)
        aux["credit"] = c
    return spx, vix, other, aux


def dollar_index(fx):
    """DXY formula applied to Fed H.10 daily rates. Before the euro (1999-01-04) the Danish krone,
    pegged to the Deutsche mark, stands for the euro block. Only changes of the index are used as features."""
    rates = fx.pivot_table(index="Date", columns="Country", values="Exchange rate").ffill(limit=5)
    lr = np.log(rates).diff()
    euro_block = lr["Euro"].where(lr.index > EURO_START, lr["Denmark"])
    r = DXY_WEIGHTS["Euro"] * euro_block + sum(w * lr[c] for c, w in DXY_WEIGHTS.items() if c != "Euro")
    level = np.exp(r.dropna().cumsum())
    # scale to the official DXY formula on the first euro day, so post-1999 levels read like the DXY
    anchor = 50.14348112 * np.exp(sum(w * np.log(rates.loc[EURO_START, c]) for c, w in DXY_WEIGHTS.items()))
    return level / level.loc[EURO_START] * anchor


def on_spx_calendar(s, index, max_gap=10):
    """Last value observed on or before each S&P 500 trading day (never a later value)."""
    s = s[~s.index.duplicated()].sort_index()
    return s.reindex(s.index.union(index)).ffill(limit=max_gap).reindex(index)


def audit(spx, vix):
    print(f"SPX {spx.index.min().date()} -> {spx.index.max().date()}  rows={len(spx)}  "
          f"dupes={spx.index.duplicated().sum()}  NaN={spx.isna().sum()}  <=0: {(spx <= 0).sum()}")
    print(f"VIX {vix.index.min().date()} -> {vix.index.max().date()}  rows={len(vix)}  "
          f"dupes={vix.index.duplicated().sum()}  NaN={vix.isna().sum()}  <=0: {(vix <= 0).sum()}")
    span = vix.index[vix.index <= spx.index.max()]
    extra = span.difference(spx.index)          # VIX rows on days the stock market was closed
    copied = (vix.loc[extra].values == vix.shift(1).loc[extra].values).sum()
    print(f"VIX rows on non-trading days (dropped): {len(extra)}  of which copy of previous value: {copied}")
    missing = spx.loc["1990-01-02":vix.index.max()].index.difference(vix.index)
    print("SPX trading days with no VIX value (rows dropped):", [d.date().isoformat() for d in missing])


def build(spx, vix, other, aux):
    df = pd.DataFrame({"spx": spx})              # everything lives on the S&P 500 trading calendar
    df["vix"] = vix.reindex(df.index)            # holiday VIX rows disappear here
    for name, series in other.items():
        df[name] = on_spx_calendar(series, df.index)
    r = np.log(df["spx"]).diff()                 # r_t = ln(S_t / S_{t-1})
    r2 = r ** 2

    # ---- features: only information available at the close of t ----
    for n in (5, 21, 63):
        df[f"rv_{n}"] = np.sqrt(ANN / n * r2.rolling(n).sum())        # uses r_{t-n+1} .. r_t
    df["log_vix"] = np.log(df["vix"])
    df["vix_mom_5"] = np.log(df["vix"] / df["vix"].shift(5))
    df["ret_5"] = np.log(df["spx"] / df["spx"].shift(5))
    df["ret_21"] = np.log(df["spx"] / df["spx"].shift(21))
    # trading activity: median volume of the last week vs the last quarter (robust to half-days)
    vol = aux["volume"].reindex(df.index)
    df["vol_ratio"] = np.log(vol.rolling(5, min_periods=3).median() / vol.rolling(63, min_periods=40).median())
    df["vol_ratio"] = df["vol_ratio"].ffill(limit=10)   # bridge the Feb-2011 data gap with the last known value
    if aux["credit"] is not None:                             # credit spread, in percentage points
        df["credit"] = on_spx_calendar(aux["credit"], df.index)
        df["credit_chg_21"] = df["credit"] - df["credit"].shift(21)
    # cross-asset, 21-day changes: dollar index and oil
    for name in other:
        df[f"{name}_chg_21"] = np.log(df[name] / df[name].shift(21))

    # ---- label: uses r_{t+1} .. r_{t+H} (future) ----
    df["rv_fwd_21"] = np.sqrt(ANN / H * r2.rolling(H).sum().shift(-H))
    iv = df["vix"] / 100
    known = df["rv_fwd_21"].notna() & iv.notna()
    # NaN where the future is not observed yet: (a > NaN) would silently give False = 0
    df["y"] = np.where(known, (df["rv_fwd_21"] > iv).astype(float), np.nan)
    df["y_lag21"] = df["y"].shift(H)             # label of t-21: its window ends at t -> known at close t
    df["pnl_short_var"] = iv ** 2 - df["rv_fwd_21"] ** 2   # short variance swap P&L proxy (variance units)
    return df


def assign_split(df):
    """Test from 2023; 'purge' = train rows whose label window reaches into the test period."""
    first_test = df.index[df.index >= TEST_START][0]
    window_end = pd.Series(df.index, index=df.index).shift(-H)   # last day used by the label of t
    df["split"] = np.where(df.index >= TEST_START, "test",
                           np.where(window_end >= first_test, "purge", "train"))
    return df


FEATURES = ["log_vix", "vix_mom_5", "rv_5", "rv_21", "rv_63", "ret_5", "ret_21", "vol_ratio",
            "usd_index_chg_21", "brent_chg_21", "y_lag21"]
CREDIT_FEATURES = ["credit", "credit_chg_21"]


def assert_no_lookahead(spx, vix, other, aux, full, features, n_checks=40, seed=0):
    """Recompute features with data truncated at t: they must be identical (no look-ahead)."""
    rng = np.random.default_rng(seed)
    dates = rng.choice(full.index[full["y"].notna() & full[features].notna().all(axis=1)], n_checks, replace=False)
    for t in dates:
        cut = {k: v.loc[:t] for k, v in other.items()}
        # credit dates are already shifted to their publication day, so cutting at t keeps only published values
        aux_cut = {k: (None if v is None else v.loc[:t]) for k, v in aux.items()}
        trunc = build(spx.loc[:t], vix.loc[:t], cut, aux_cut).loc[t, features].astype(float)
        assert np.allclose(trunc.values, full.loc[t, features].astype(float).values, rtol=1e-12, atol=1e-12), t
    print(f"look-ahead test passed on {n_checks} random dates (features recomputed with data cut at t)")


def assert_label_by_hand(full, n_checks=40, seed=1):
    rng = np.random.default_rng(seed)
    r = np.log(full["spx"]).diff().values
    pos = rng.choice(np.where(full["y"].notna())[0], n_checks, replace=False)
    for p in pos:
        rv = np.sqrt(ANN / H * np.sum(r[p + 1:p + H + 1] ** 2))
        assert int(rv > full["vix"].iloc[p] / 100) == int(full["y"].iloc[p]), full.index[p]
    print(f"label recomputed by explicit loop on {n_checks} random dates: identical")


def main():
    spx, vix, other, aux = load_raw()
    audit(spx, vix)
    for k, v in other.items():
        print(f"{k}: {v.index.min().date()} -> {v.index.max().date()}  rows={len(v)}  <=0: {(v <= 0).sum()}")
    features = FEATURES + (CREDIT_FEATURES if aux["credit"] is not None else [])
    print("credit spread file:", "found" if aux["credit"] is not None else "absent (feature skipped)")
    print(f"volume: {aux['volume'].isna().sum()} values set to missing (audit errors)")
    full = assign_split(build(spx, vix, other, aux))
    assert_no_lookahead(spx, vix, other, aux, full, features)
    assert_label_by_hand(full)

    keep = full.loc["1990-01-01":].dropna(subset=features + ["y"])

    # ---- export with readable names; volatilities and returns in % (same unit as the VIX) ----
    data = pd.DataFrame(index=keep.index)
    data["vix"] = keep["vix"]                                      # implied vol for the next 30 days, %
    data["vix_log"] = keep["log_vix"]
    data["vix_change_5d"] = 100 * keep["vix_mom_5"]                # % (log change)
    data["realized_vol_past_5d"] = 100 * keep["rv_5"]              # %, annualised
    data["realized_vol_past_21d"] = 100 * keep["rv_21"]
    data["realized_vol_past_63d"] = 100 * keep["rv_63"]
    data["sp500_return_5d"] = 100 * keep["ret_5"]                  # % (log return)
    data["sp500_return_21d"] = 100 * keep["ret_21"]
    data["dollar_index_change_21d"] = 100 * keep["usd_index_chg_21"]  # > 0: dollar strengthening
    data["brent_oil_return_21d"] = 100 * keep["brent_chg_21"]
    data["sp500_volume_5d_vs_3m"] = 100 * keep["vol_ratio"]         # > 0: more trading than usual
    if aux["credit"] is not None:
        data["credit_spread_baa10y"] = keep["credit"]               # Baa corporate minus 10y Treasury, pp
        data["credit_spread_change_21d"] = 100 * keep["credit_chg_21"]  # basis points
    data["seller_lost_last_month"] = keep["y_lag21"].astype(int)   # label of t-21, known at t
    data["target_seller_loses_next_month"] = keep["y"].astype(int)
    data["split"] = keep["split"]

    evalf = pd.DataFrame(index=keep.index)
    evalf["vix"] = keep["vix"]
    evalf["realized_vol_next_21d"] = 100 * keep["rv_fwd_21"]       # FUTURE: never a feature
    evalf["seller_pnl_variance"] = keep["pnl_short_var"]           # FUTURE: (vix/100)^2 - (rv/100)^2
    evalf["target_seller_loses_next_month"] = keep["y"].astype(int)
    evalf["split"] = keep["split"]

    OUT.mkdir(parents=True, exist_ok=True)
    data.to_csv(OUT / "vix_dataset.csv", float_format="%.6f", date_format="%Y-%m-%d")
    evalf.to_csv(OUT / "vix_eval_only.csv", float_format="%.6f", date_format="%Y-%m-%d")

    y = data["target_seller_loses_next_month"]
    print(f"\nvix_dataset.csv: {len(data)} rows, {data.index.min().date()} -> {data.index.max().date()}")
    print(y.groupby(data["split"]).agg(rows="size", positives="sum", prevalence="mean").round(4))
    print(f"overall prevalence: {y.mean():.4f}")


if __name__ == "__main__":
    main()
